﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RestaurantBLL.Services
{
    public class FeedbackService
    {
    }
}
