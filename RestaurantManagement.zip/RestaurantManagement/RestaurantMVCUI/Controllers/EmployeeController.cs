﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using RestaurantEntity;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace RestaurantMVCUI.Controllers
{
    public class EmployeeController : Controller
    {
        private IConfiguration _configuration;
        public EmployeeController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public async Task<IActionResult> Index()
        {
            IEnumerable<Employee> employees = null;
            using (HttpClient client = new HttpClient())
            {
                //StringContent content = new StringContent(JsonConvert.SerializeObject(movie), Encoding.UTF8, "application/json");
                string endPoint = _configuration["WebApiBaseUrl"] + "Employee/GetGetEmployees";
                using (var response = await client.GetAsync(endPoint))
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        var result = await response.Content.ReadAsStringAsync();
                        employees = JsonConvert.DeserializeObject<IEnumerable<Employee>>(result);
                    }
                }
            }
            return View(employees);
        }
    

        public IActionResult EmpLogin()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> EmpLogin(Employee employeeInfo)
        {
            ViewBag.status = "";
            using (HttpClient client = new HttpClient())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(employeeInfo), Encoding.UTF8, "application/json");
                string endPoint = _configuration["WebApiBaseUrl"] + "Employee/Login";
                using (var response = await client.PostAsync(endPoint, content))
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                        return RedirectToAction("Index", "Home");
                    else
                    {
                        ViewBag.status = "Error";
                        ViewBag.message = "Wrong credentials!";
                    }
                }
            }
            return View();
        }
        public IActionResult EmpEntry()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> EmpEntry(Employee employee)
        {
            ViewBag.status = "";
            using (HttpClient client = new HttpClient())
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(employee), Encoding.UTF8, "application/json");
                string endPoint = _configuration["WebApiBaseUrl"] + "Employee/AddEmployee";
                using (var response = await client.PostAsync(endPoint, content))
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        ViewBag.status = "Ok";
                        ViewBag.message = "Employee created  Successfully";
                    }
                    else
                    {
                        ViewBag.status = "Error";
                        ViewBag.message = "Wrong Entries....!!!  :)";
                    }
                }
            }

            return View();
        }

        //public async Task<IActionResult> EditEmp(int employeeId)
        //{

        //    Employee employee = null;
        //    using (HttpClient client = new HttpClient())
        //    {
        //        string endPoint = _configuration["WebApiBaseUrl"] + "Employee/GetEmployeeById?employeeId=" + employeeId;
        //        using (var response = await client.GetAsync(endPoint))
        //        {
        //            if (response.StatusCode == System.Net.HttpStatusCode.OK)
        //            {
        //                var result = await response.Content.ReadAsStringAsync();
        //                employee = JsonConvert.DeserializeObject<Employee>(result);
        //            }
        //        }
        //    }
        //    return View(employee);
        //}

        //[HttpPost]
        //public async Task<IActionResult> EditEmp(Employee employee)
        //{
        //    ViewBag.status = "";
        //    using (HttpClient client = new HttpClient())
        //    {
        //        StringContent content = new StringContent(JsonConvert.SerializeObject(employee), Encoding.UTF8, "application/json");
        //        string endPoint = _configuration["WebApiBaseUrl"] + "Employee/UpdateEmployee";
        //        using (var response = await client.PutAsync(endPoint, content))
        //        {
        //            if (response.StatusCode == System.Net.HttpStatusCode.OK)
        //            {
        //                ViewBag.status = "Ok";
        //                ViewBag.message = "Employee deatils Saved Successfully";
        //            }
        //            else
        //            {
        //                ViewBag.status = "Error";
        //                ViewBag.message = "Wrong Entries....!!!  :)";
        //            }
        //        }
        //    }
        //    return View();
        //}

        //public async Task<IActionResult> DeleteEmp(int employeeId)
        //{
        //    Employee employee = null;
        //    using (HttpClient client = new HttpClient())
        //    {
        //        string endPoint = _configuration["WebApiBaseUrl"] + "Employee/GetEmployeeById?employeeId==" + employeeId;
        //        using (var response = await client.GetAsync(endPoint))
        //        {
        //            if (response.StatusCode == System.Net.HttpStatusCode.OK)
        //            {
        //                var result = await response.Content.ReadAsStringAsync();
        //                employee = JsonConvert.DeserializeObject<Employee>(result);
        //            }
        //        }
        //    }

        //    return View(employee);
        //}

        //[HttpPost]
        //public async Task<IActionResult> DeleteEmp(Employee employee)
        //{
        //    ViewBag.status = "";
        //    using (HttpClient client = new HttpClient())
        //    {

        //        string endpoint = _configuration["WebApiBaseUrl"] + "Employee/DeleteEmployee?employeeId=" + employee.EmpId;
        //        using (var response = await client.DeleteAsync(endpoint))
        //        {
        //            if (response.StatusCode == System.Net.HttpStatusCode.OK)
        //            {
        //                ViewBag.status = "Ok";
        //                ViewBag.message = "Show details deleted succesfully";
        //            }
        //            else
        //            {
        //                ViewBag.staus = "Error";
        //                ViewBag.message = "Wrong Entries";
        //            }
        //        }
        //    }
        //    return View();
        //}



    }
}