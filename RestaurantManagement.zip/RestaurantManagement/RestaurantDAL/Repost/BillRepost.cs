﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RestaurantDAL.Repost
{
    public class BillRepost
    {
    }
}
